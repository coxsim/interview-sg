package com.example.marketmaker;

import java.util.HashMap;
import java.util.Properties;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;

import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;

/**
 * HSBC verion of libraries for pricing of quote requests.
 * <P>
 * This is the main class responsible for services provided by
 * Quote Request Engine.
 */
public class HSBCQuoteEngine implements QuoteCalculationEngine {

	private double defulatBuySpread;
	private double defulatSellSpread;
	private String spreadFile;
	private HashMap<Integer, Tuple<Double, Double> > spreadTable;

	private int port;

	private HSBCReferencePriceSource priceSource;

	private int workingThreadNumber;
	private int clientMaxIdleTime;

	public static void main(String[] args) throws Exception {

		HSBCQuoteEngine engine = new HSBCQuoteEngine();
		
		engine.initializeEngine();
		engine.run();
	}

	/**
	 * initializeEngine is used to initialize the quote request engine:
	 * loading configurations, initializaing engine internal state
	 * variables, initializaing spread table.
	 * @return Nothing.
	 */
	public void initializeEngine () {
		
		System.out.println("HSBCQuoteEngine: initialize engine");

		// load configuration
		Properties prop = new Properties();
		String fileName = "./cfg/config_file";
		InputStream is;

		try {
			is = new FileInputStream(fileName);
			prop.load(is);
		} catch (FileNotFoundException e) {
			System.out.println("HSBCQuoteEngine: configuration file not found - " + fileName);
		} catch (IOException e) {
			System.out.println("HSBCQuoteEngine: unknown error on configuration file loading");
		}

		// initialize parameters

		spreadFile = prop.getProperty("engine.spread_file");
		defulatBuySpread = Double.parseDouble(prop.getProperty("engine.defulat_buy_spread"));
		defulatSellSpread = Double.parseDouble(prop.getProperty("engine.defulat_sell_spread"));

		port = Integer.parseInt(prop.getProperty("engine.port"));
		
		String market_data_file = prop.getProperty("engine.market_data_file");
		int frequency = Integer.parseInt(prop.getProperty("engine.frequency"));

		workingThreadNumber = Integer.parseInt(prop.getProperty("engine.threads"));
		clientMaxIdleTime = Integer.parseInt(prop.getProperty("engine.client_max_idle_time")) * 1000;

		// initialize price source
		HSBCReferencePriceListener listener = new HSBCReferencePriceListener();

		priceSource = new HSBCReferencePriceSource(market_data_file, frequency);
		priceSource.subscribe(listener);

		initializeSpreadTable ();

	}

	/**
	 * initializeSpreadTable is used to initialize the BUY/SELL spread of
 	 * any security not using default spreads.
	 * @return Nothing.
	 */
	private void initializeSpreadTable () {

		System.out.println("HSBCQuoteEngine: initialize spread tables");
		spreadTable = new HashMap<Integer, Tuple<Double, Double>>();

		try {

			// we have some reference price changes
			BufferedReader in = new BufferedReader(new FileReader(spreadFile));
			String str;

			while((str = in.readLine()) != null){
				str = str.trim();
				if (!str.isEmpty()) {

					System.out.println("initializeSpreadTable: loading " + str);

					String[] values = str.split(",");
					int securityId = Integer.parseInt(values[0]);
					double buySpread = Double.parseDouble(values[1]);
					double sellSpread = Double.parseDouble(values[2]);

					Tuple<Double, Double> tuple = new Tuple<Double, Double>(buySpread, sellSpread);
					spreadTable.put(securityId, tuple);
				}				
			}

		} catch (FileNotFoundException e) {
			System.out.println("initializeSpreadTable: spread file not found - " + spreadFile);
		} catch (IOException e) {
			System.out.println("initializeSpreadTable: unknown error on spread file loading");
		}

	}

	/**
	 * This is the main procedure run by the engine.
	 * <P>
	 * This proc listens on port 8888 (configurable), and accept client connection if there is
	 * still avaiable processing unit.
	 * 
	 * @return Nothing.
	 * @exception InterruptedException we would like the engine to halt, if such expcetion occurred
	 * @exception IOException we would like the engine to halt, if such expcetion occurred
	 */
	public void run () throws InterruptedException, IOException {

		System.out.println("HSBCQuoteEngine: start to run engine");
		ThreadPoolExecutor pool = (ThreadPoolExecutor) Executors.newFixedThreadPool(workingThreadNumber);

		ServerSocket serverSocket = new ServerSocket(port);

		// start socket listening

		while (true) {

			// Call accept() to receive the next connection
			Socket socket = serverSocket.accept();

			if (pool.getActiveCount() < workingThreadNumber) {
				// if we still have an empty slot
				Runnable worker = new QuoteEngineWorkerThread(this, socket);
				pool.execute(worker);
			} else {
				// otherwise close the socket immidately
				socket.close();
			}
		
		}

		//pool.shutdown();
		//while (!pool.isTerminated()) {
		//	Thread.sleep(100);
		//}
	}

	/**
	 * handleClientRequest is the actual procedure handling client request.
	 * <P>
	 * This proc polls the client request from the socket, and write the 
	 * response to the socket.
	 *
	 * @param socket	socket associated with client.
	 * @return Nothing.
	 */
	public void handleClientRequest(Socket socket) {

		int securityId;
		double referencePrice; 
		boolean buy;
		int quantity;

		String response;
		String line;

		BufferedReader in = null;
		PrintWriter out = null;

		try {
			
			// Get input and output streams
			in = new BufferedReader( new InputStreamReader( socket.getInputStream() ) );
			out = new PrintWriter( socket.getOutputStream() );

			// to clear slots for other clients
			socket.setSoTimeout(clientMaxIdleTime);
 
			while(true) {

				try {

					line = in.readLine();
					if (line == null || line.length() == 0) {
						break;
					}

					//System.out.println("client input: " + line);

					line = line.trim();
					String[] values = line.split(" ");

					securityId = Integer.parseInt(values[0]);
					buy = (values[1].equals("BUY")) ? true : false;
					quantity = Integer.parseInt(values[2]);

					//System.out.println(securityId + " " + buy + " " + quantity);
					
					referencePrice = priceSource.get(securityId);
					//System.out.println("client output: " + referencePrice);
					
					double quote = calculateQuotePrice(securityId, referencePrice, buy, quantity);
					response = String.format("%.2f", quote);

				} catch (InvalidSecurityException e) {
					response = "NA";
				} catch (SocketTimeoutException e) {
					break;
				}

				//System.out.println("client output: " + response);

				out.println(response);
				out.flush();

            }

			// Close our connection
			in.close();
			out.close();
            socket.close();

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println( "handleClientRequest: unprocessed exception!" );

		}

	}

	/**
	 * Calculate the appropriate price for a quote request on a security.
 	 *
	 * @param securityId     security identifier
	 * @param referencePrice reference price to calculate theory price from (e.g. underlying security's price)
	 * @param buy            {@code true} if buy, otherwise sell
	 * @param quantity       quantity for quote
	 * @return calculated quote price
	 */
	public double calculateQuotePrice(int securityId, double referencePrice, boolean buy, int quantity) {
		
		double spread = buy ? defulatBuySpread : defulatSellSpread;
		int sign = buy ? 1 : -1;
		double quote;

		// check if we have a special value for any particular security
		Tuple<Double, Double> value = spreadTable.get(securityId);
		if (value != null) {
			spread = buy ? value.x : value.y;
		}

		quote = referencePrice * (1 + spread * sign) * quantity;

		return quote;

	}
}

/**
 * Source for Quote Engine Worker Thread.
 * This is a wrapper class for Quote Request client handling thread.
 */
class QuoteEngineWorkerThread implements Runnable {
  
    private HSBCQuoteEngine engine;
	private Socket socket;
    
    public QuoteEngineWorkerThread(HSBCQuoteEngine engine, Socket socket){
        this.engine = engine;
		this.socket = socket;
    }

    public void run() {
		engine.handleClientRequest(socket);
    }

}
