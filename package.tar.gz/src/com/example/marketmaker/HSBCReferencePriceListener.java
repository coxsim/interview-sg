package com.example.marketmaker;

import java.util.HashMap;
import java.util.List;

/**
 * Source for HSBC reference price listeners.
 * <P>
 * This is the actual class holding the security price table.
 */
public class HSBCReferencePriceListener implements ReferencePriceSourceListener {

	private HashMap<Integer, Double> marketQuoteTable;

	public HSBCReferencePriceListener () {
		marketQuoteTable = new HashMap<Integer, Double>();
	}

	/**
	 * referencePriceChanged is the method used to update a single secuirty price.
	 * @param securityId security ID to update the price for.
	 * @param price		to-be-updated price.
	 * @return Nothing.
	 */
	public void referencePriceChanged(int securityId, double price) {
		synchronized(this){
			marketQuoteTable.put(securityId, price);
		}
	}

	/**
	 * referencePriceChanged is the method used to update bulk of secuirty prices.
	 * @param list	bulk of security/price tuple to update.
	 * @return Nothing.
	 */
	public void referencePriceChanged(List<Tuple<Integer, Double>> list) {
		synchronized(this){
			for (Tuple<Integer, Double> element : list) {
				System.out.println("updating " + element.x + " " + element.y);
				marketQuoteTable.put(element.x, element.y);
			}
		}
	}

	/**
	 * This is the method used to retrieve the price of a particular security.
	 * @param securityId	security ID to retreive the price for.
	 * @return double		the price retrieved for the particular security.
	 * @exception InvalidSecurityException On invalid security ID.
	 */
	public double get(int securityId) throws InvalidSecurityException {

		Double value = null;
		synchronized(this){
			value = marketQuoteTable.get(securityId);
		}

		if (value == null) {
			InvalidSecurityException e = new InvalidSecurityException("invalid security code");
			throw e;
		}

		return value;
	}

}