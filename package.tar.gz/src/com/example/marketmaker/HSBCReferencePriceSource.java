package com.example.marketmaker;

import java.util.ArrayList;
import java.util.List;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.File;

import java.io.FileNotFoundException;
import java.io.IOException;

/**
 * Source for HSBC Reference Price Source.
 * <P>
 * This is a facade class for price-related services:subscribing to
 * the market data, price query of the security.
 */
public class HSBCReferencePriceSource implements ReferencePriceSource {

	private String marketDataSource;
	private int frequency;

	private HSBCReferencePriceListener priceSourceListener;

	public HSBCReferencePriceSource (String file, int seconds) {
		marketDataSource = file;
		frequency = seconds * 1000;
	}

	/**
	 * subscribe is the method to initiate the price subscription thread.
	 * @param listener	object holding the call back function for price update.
	 * @return Nothing.
	 */
	public void subscribe(ReferencePriceSourceListener listener) {

		priceSourceListener = (HSBCReferencePriceListener) listener;
		
		// implement a dummy market data source
		// this subscribe scans the file every second
		(new ReferencePriceSourceThread(this)).start();
	}

	/**
	 * This is the wrapper method to further call listener's get method.
	 * @param securityId	security ID to retreive the price for.
	 * @return double		the price retrieved for a particular security.
	 * @exception InvalidSecurityException On invalid security ID.
	 */
    public double get(int securityId) throws InvalidSecurityException {
		return priceSourceListener.get(securityId);
	}

	/**
	 * This is the actual method subscribing to the market data update.
	 * <P>
	 * Under our design, we emulate the market data update via file changes.
	 * The price update is delivered to the file dat/market_data_file. This
	 * proc polls for update on this file every 1 second (configurable).
	 *
	 * @return Nothing.
	 */
	public void subscribeProc() {

		long lastFileChangeTime = 0;
		List<Tuple<Integer, Double>> list = new ArrayList<Tuple<Integer, Double>>();
		File file = null;

		while (true) {

			try {

				if (file == null) {
					file = new File(marketDataSource);
				}

				long lastChangeTime = file.lastModified();
				if (lastChangeTime > lastFileChangeTime) {

					lastFileChangeTime = lastChangeTime;

					// we have some reference price changes
					BufferedReader in = new BufferedReader(new FileReader(marketDataSource));
					String str;

					while((str = in.readLine()) != null){
						str = str.trim();
						if (!str.isEmpty()) {
							String[] values = str.split(",");
							int securityId = Integer.parseInt(values[0]);
							double price = Double.parseDouble(values[1]);
							list.add(new Tuple<Integer, Double>(securityId, price));
						}				
					}

					priceSourceListener.referencePriceChanged(list);
					list.clear();
				}

				Thread.sleep(frequency);
			} catch (FileNotFoundException e) {
				file = null;
			} catch (IOException e) {
				file = null;
			} catch (InterruptedException e) {
				;
			}
			
		}
	}

}

/**
 * Source for Reference Price Source Thread.
 * This is a wrapper class for price subscription thread.
 */
class ReferencePriceSourceThread extends Thread {

	HSBCReferencePriceSource priceSource;

	public ReferencePriceSourceThread (HSBCReferencePriceSource priceSource) {
		this.priceSource = priceSource;
	}

    public void run() {
        priceSource.subscribeProc();
    }

}

