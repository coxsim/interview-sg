package com.example.marketmaker;

/**
 * Source for InvalidSecurityException.
 * <P>
 * This is a lightweight exception class used to indicate
 * the security id is not supported by the Quote Request
 * Server.
 */
public class InvalidSecurityException extends Exception {
	public InvalidSecurityException(String message) {
		super(message);
	}
}