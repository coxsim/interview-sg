package com.example.marketmaker;

/**
 * Source for Tuple class.
 * This is a generic class holding pair of values.
 */
public class Tuple<X, Y> {

	public final X x;
	public final Y y;
  
	public Tuple(X x, Y y) {
		this.x = x;
		this.y = y;
	}

	/**
	 * toString method is used to return a text representation of
	 * the Tuple object.
	 * @return String	a text representation of the Tuple object.
	 */
	public String toString() {
		return String.format("(%s, %s)", x, y);
	}
  
}
